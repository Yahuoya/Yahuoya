; ---------------------------------------------------------
; 作业2：利用段码在 LED 环境中显示学号 (870522)
; ---------------------------------------------------------

dseg   segment
    ; 定义 870522 对应的段码 (DW 定义会按照低位在前、高位在后的顺序存入内存)
    ; 8: FFFF, 7: FF00, 0: FFFC, 5: F7EF, 2: FDFB, 2: FDFB
    led_data dw 0FFFFH, 0FF00H, 0FFFCH, 0F7EFH, 0FDFBH, 0FDFBH
dseg   ends

sseg   segment stack
    db 20 dup('stack')
sseg   ends

cseg   segment
       assume cs:cseg, ds:dseg, ss:sseg
start:
       ; 1. 获取 LED.COM 存放在 0000:0072H 的段基址
       mov ax, 0
       mov ds, ax
       mov ax, ds:[72h]    ; 读取 0:72h 处的字单元 (如 92 01 -> 0192H)
       mov es, ax          ; 设置 ES 为 LED 显存的段基址

       ; 2. 初始化 DS 指向本程序的数据段
       mov ax, dseg
       mov ds, ax

       ; 3. 将段码写入到 ES:110H 开始的内存中
       mov si, offset led_data
       mov di, 110h        ; 题目指定的起始偏移量 110H
       mov cx, 6           ; 共有 6 个数字需要显示

show_loop:
       mov ax, [si]        ; 从数据段取出一个字 (包含两个字节的段码)
       mov es:[di], ax     ; 写入到 LED 指定的内存位置
       add si, 2           ; 源指针移动 2 字节
       add di, 2           ; 目标指针移动 2 字节 (每个数字占一个字)
       loop show_loop

       ; 4. 程序结束，返回 DOS
       mov ah, 4ch
       int 21h
cseg   ends
       end start